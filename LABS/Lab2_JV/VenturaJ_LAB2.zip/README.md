# COSC311 Lab 2

by Justin Ventura

### All information needed can be located in the .ipynb file.
